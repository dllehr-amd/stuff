/*
    Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
*/

#ifndef ROCM_WRAPPER_EXPORT_H
#define ROCM_WRAPPER_EXPORT_H

#if defined(ROCM_NO_WRAPPER_HEADER_WARNING) || defined(ROCM_WRAPPER_GAVE_WARNING)
/* include file */
#include "../../../include/miopen/export.h"
#else
#ifndef ROCM_HEADER_WRAPPER_WERROR
#define ROCM_HEADER_WRAPPER_WERROR 0
#endif
#if ROCM_HEADER_WRAPPER_WERROR  /* ROCM_HEADER_WRAPPER_WERROR 1 */
#error "This file is deprecated. Use the header file from /opt/rocm/include/miopen/export.h by using #include <miopen/export.h>"
#else  /* ROCM_HEADER_WRAPPER_WERROR 0 */
/* give warning */
#if defined(_MSC_VER)
#pragma message(": warning:This file is deprecated. Use the header file from /opt/rocm/include/miopen/export.h by using #include <miopen/export.h>")
#elif defined(__GNUC__)
#warning "This file is deprecated. Use the header file from /opt/rocm/include/miopen/export.h by using #include <miopen/export.h>"
#endif
#endif  /* ROCM_HEADER_WRAPPER_WERROR */
/* include file */
#define ROCM_WRAPPER_GAVE_WARNING
#include "../../../include/miopen/export.h"
#undef ROCM_WRAPPER_GAVE_WARNING
#endif /* defined(ROCM_NO_WRAPPER_HEADER_WARNING) || defined(ROCM_WRAPPER_GAVE_WARNING) */

#endif /* ROCM_WRAPPER_EXPORT_H */


